package com.neu.ir.query;

import java.util.ArrayList;
import java.util.Arrays;

public class Query {
	private int queryNo;

	private ArrayList<String> queryTerms;
	
	public int getQueryNo() {
		return queryNo;
	}

	public void setQueryNo(int queryNo) {
		this.queryNo = queryNo;
	}

	public ArrayList<String> getQueryTerms() {
		return queryTerms;
	}

	public void setQueryTerms(ArrayList<String> queryTerms) {
		this.queryTerms = queryTerms;
	}



}
